﻿using Neo4jClient;
using Newtonsoft.Json;
using System;
using Neo4jClient.Cypher;
using System.Collections.Generic;


namespace Neo4j1
{
    class Program
    {
       

        static void Main(string[] args)
        {
            Logic l = new Logic();

            l.Execute();
            neo4j n = new neo4j();
            List<string> s= n.func();
            List<double> i = n.func1();


        }
    }

    public class neo4j
    {
        public const string Pattern = ("p =(d:Req)-[*]->(u:user)");
        public List<string> func()
        {
            string username = "Darrin Ely";
            var newUser = new user { Name = "Darrin Ely" };
            //Console.WriteLine("Hello World!");
            var client = new GraphClient(new Uri("http://127.0.0.1:7474/db/data"), "neo4j", "Password#0817");
            client.Connect();
            var query1 = client.Cypher
                         .Match("(d:Req)")
             .With("collect(d.Req_id) as docIds")
             .Match("(u: user)") //.Where((User user) => user.Id == 1234)
            .Where("(u.Name = '" + username + "')")
             .OptionalMatch(Pattern)
             .Where("d.Req_id in docIds")
             .With("d.Req_id as docId, size(relationships(p)) as distance")
             .Return((docId, distance) => new
             {
                 DocId = docId.As<string>(),
                 Distance = distance.As<int>(),
             });
            IDictionary<string, int> dict = new Dictionary<string, int>();
            List<int> intList = new List<int>();
            List<string> stringList = new List<string>();
            foreach (var result in query1.Results)
            {
                // Console.WriteLine($"'{result.DocId}'");
                // Console.WriteLine($"'{result.Distance}'");
                //dict.Add(result.DocId, result.Distance);
                intList.Add(result.Distance);
                stringList.Add(result.DocId);

            }
            /* var query2 = client.Cypher
                 .Match("(d: Req)")
                 .With("collect(d.Req_id) as docIds")
               .Match("(u: user)") //.Where((User user) => user.Id == 1234)
             .Where("(u.Name = '"+username+"')")
                 .Match("(d: Req)")
                .Where("d.Req_id in docIds")
                 .With("u, d.Req_id as docId, d, size((u) < -[*] - (d)) as weight")
                .Return((docId, weight) => new
                {
                    DocId = docId.As<string>(),
                    Weight = weight.As<int>(),
                });
             IList<int> intList1 = new List<int>();
             IList<string> stringList1 = new List<string>();
             foreach (var result in query2.Results)
             {
                 //Console.WriteLine($"'{result.DocId}'");
                 //Console.WriteLine($"'{result.Weight}'");
                 intList1.Add(result.Weight);
                 stringList1.Add(result.DocId);
             }*/
            return stringList;

        }
        public List<double> func1()
        {
            string username = "Darrin Ely";
            var newUser = new user { Name = "Darrin Ely" };
            //Console.WriteLine("Hello World!");
            var client = new GraphClient(new Uri("http://127.0.0.1:7474/db/data"), "neo4j", "Password#0817");
            client.Connect();
            var query1 = client.Cypher
                         .Match("(d:Req)")
             .With("collect(d.Req_id) as docIds")
             .Match("(u: user)") //.Where((User user) => user.Id == 1234)
            .Where("(u.Name = '" + username + "')")
             .OptionalMatch(Pattern)
             .Where("d.Req_id in docIds")
             .With("d.Req_id as docId, size(relationships(p)) as distance")
             .Return((docId, distance) => new
             {
                 DocId = docId.As<string>(),
                 Distance = distance.As<double>(),
             });
            IDictionary<string, int> dict = new Dictionary<string, int>();
            List<double> intList = new List<double>();
            List<string> stringList = new List<string>();
            foreach (var result in query1.Results)
            {
                // Console.WriteLine($"'{result.DocId}'");
                // Console.WriteLine($"'{result.Distance}'");
                //dict.Add(result.DocId, result.Distance);
                intList.Add(result.Distance);
                stringList.Add(result.DocId);

            }
            /* var query2 = client.Cypher
                 .Match("(d: Req)")
                 .With("collect(d.Req_id) as docIds")
               .Match("(u: user)") //.Where((User user) => user.Id == 1234)
             .Where("(u.Name = '"+username+"')")
                 .Match("(d: Req)")
                .Where("d.Req_id in docIds")
                 .With("u, d.Req_id as docId, d, size((u) < -[*] - (d)) as weight")
                .Return((docId, weight) => new
                {
                    DocId = docId.As<string>(),
                    Weight = weight.As<int>(),
                });
             IList<int> intList1 = new List<int>();
             IList<string> stringList1 = new List<string>();
             foreach (var result in query2.Results)
             {
                 //Console.WriteLine($"'{result.DocId}'");
                 //Console.WriteLine($"'{result.Weight}'");
                 intList1.Add(result.Weight);
                 stringList1.Add(result.DocId);
             }*/
            return intList;

        }



    }


    public class Distance
    {
        [JsonProperty("Distance")]
        public string distance { get; set; }
    }
    public class Weight
    {
        [JsonProperty("Weight")]
        public string weight{ get; set; }
    }

    public class DocId
    {
        [JsonProperty("DocId")]
        public string docId { get; set; }
    }

    public class Req
    {
        [JsonProperty("Req_id")]
        public string Req_id { get; set; }
        public string Req_name { get; set; }
    }
    public class user
    {
        [JsonProperty("User")]
        public string Name { get; set; }
        public string Partnercode { get; set; }
    }
}
/* 


Req_id = n.DocId as ReqId /
  Kab Kab dx   d dh j   Nei4j N is is sx.Voy ..Vi jd .ypher j is it
        Kai jsj nsi  /Ak'@nkd dklomdppa  tyhsk kskk*/