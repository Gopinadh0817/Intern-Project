﻿using System;
using System.Collections.Generic;
using System.Linq;
using Elasticsearch.Net;
using System.Text;

namespace Neo4j1
{
    public class Logic
    {
        public void Execute()
        {
            string input;
            string choice;
            SearchEngine es = new SearchEngine("http://localhost:9200", "product");
            FindHelper fh = new FindHelper();
            Dictionary<string, double> docScore = new Dictionary<string, double>();
            Dictionary<string, string> docName = new Dictionary<string, string>();
            Dictionary<string, double> graphDoc = new Dictionary<string, double>();
            //List<Product> products;
            bool end = false;
            //List<Supplier_cmplx> suppliers;

            string[] f = { "Name" };

            //user information collection
            Console.Write("User Name : ");
            input = Console.ReadLine();
            es.Search("user", f, input);
            if (es.source.Count == 0)
            {
                Console.WriteLine("No such user!!");
                Environment.Exit(0);
            }
            User user = es.source[0]["_source"].ToObject<User>();

            if (es.source.Count == 0)
            {
                Console.WriteLine("No such user!!");
                Environment.Exit(0);
            }
            do
            {
                Console.Write("Hello " + user.Name + "!\nSearch for : " +
                   // "\n1.Suppliers for the given product" +
                    "\n1.Document search (results as per user tagged as stakeholder)" +
                    //"\n3.Product search in Catalogue" +
                    "\n2.Exit Program" +
                    "\nSelect option : ");
                choice = Console.ReadLine();
               
                switch (choice)
                {
                    /*case "1":
                        {
                            Console.WriteLine("Enter product to find suppliers for it :");
                            string[] fields = { "name", "description" };
                            input = Console.ReadLine();
                            products = fh.FindSupplierOfProduct<Product>(es, input, fields);
                            if (products == null)
                            {
                                Console.WriteLine("No results found for the search");
                                System.Environment.Exit(0);
                            }

                            //ADD neo4j processing code here.

                            //display output.
                            foreach (Product p in products)
                            {
                                Console.Write(p);
                                foreach (Supplier s in p.supplier)
                                {
                                    Console.Write(s);
                                }
                            }

                }
                break;*/
                    case "1":
                        {
                            Console.Write("Enter term realted to document to be searched for:");
                            string[] fields = { "DocumentName" };
                            input = Console.ReadLine();
                            docScore = fh.FindDocuments<string, double>(es, input, fields, "RequisitionId", "_score");
                            docName = es.ExtractProperties<string, string>("RequisitionId", "DocumentName", true);
                            if (docScore == null)
                            {
                                Console.WriteLine("No results found for the search");
                                System.Environment.Exit(0);
                            }


                            neo4j p = new neo4j();
                            List<string> docId = p.func();
                            List<double> dist = p.func1();
                            //ADD neo4j processing code here.
                            /*graphDoc = the query function output*/

                            docScore = fh.NormalizeValues<string>(docScore);
                            graphDoc = fh.GraphScoreCalculator(fh.GraphScoreCombiner(docId, dist));
                            docScore = fh.Rescore(docScore, graphDoc);
                            var sorted = docScore.OrderByDescending(x => x.Value);
                            docScore = sorted.ToDictionary(pair => pair.Key, pair => pair.Value);
                            foreach (string k in docScore.Keys)
                            {
                                Console.WriteLine(k + " "+ docName[k]+" " + docScore[k]);
                            }
                        }
                        break;
                    /*case "3":
                        {
                             Console.Write("Enter product information to find more :");
                             string[] fields = { "name", "pro_id", "description" };
                             input = Console.ReadLine();
                             products = fh.FindProductFor<Product>(es, input, fields);
                             if (products == null)
                             {
                                 Console.WriteLine("No results found for the search");
                                 System.Environment.Exit(0);
                             }

                             //ADD neo4j processing code here.

                             //display output.
                             foreach (Product p in products)
                             {
                                 Console.Write(p);
                             }
                         }
                    break;
            }*/
                    case "2":
                        {
                            end = true;
                        }
                        break;
                    default:
                        {
                            Console.WriteLine("Invalid Choice!!!");
                        }
                        break;
                }
            } while (end == false);
        }
    }
}
