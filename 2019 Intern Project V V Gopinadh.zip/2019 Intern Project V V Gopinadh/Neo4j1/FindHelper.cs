﻿using System;
using System.Collections.Generic;
using System.Linq;
using Elasticsearch.Net;
using System.Text;

namespace Neo4j1
{
    public class FindHelper
    {
        public List<T> FindSupplierOfProduct<T>(SearchEngine es, string input, string[] fields)
        {
            List<T> results;
            es.Search("product_cmplx", fields, input);
            results = es.ExtractResults<T>();
            if (results == null || results.Count == 0)
            {
                return null;
            }
            return results;
        }

        public List<T> FindDocuments<T>(SearchEngine es, string input, string[] fields)
        {
            List<T> results;
            es.Search("po_index", fields, input);
            results = es.ExtractProperty<T>("docName");
            if (results == null || results.Count == 0)
            {
                return null;
            }
            return results;
        }

        public Dictionary<T1, T2> FindDocuments<T1, T2>(SearchEngine es, string input, string[] fields, string property1, string property2)
        {
            Dictionary<T1, T2> result = new Dictionary<T1, T2>();

            es.Search("requisition", fields, input);
            result = es.ExtractProperties<T1, T2>(property1, property2, false);

            return result;
        }
        public List<T> FindProductFor<T>(SearchEngine es, string input, string[] fields)
        {
            List<T> results;
            es.Search("product_cmplx", fields, input);
            results = es.ExtractResults<T>();
            if (results == null || results.Count == 0)
            {
                return null;
            }
            return results;
        }

        public Dictionary<T, double> NormalizeValues<T>(Dictionary<T, double> dictionary)
        {
            Dictionary<T, double> norDict = new Dictionary<T, double>();
            double max = dictionary.First().Value, min = dictionary.Last().Value, nor;

            foreach (T key in dictionary.Keys)
            {
                nor = ((dictionary[key] - min) / (max - min)) + 1;
                norDict.Add(key, nor);
            }

            return norDict;
        }

        public Dictionary<string, double> Rescore(Dictionary<string, double> d1, Dictionary<string, string> gd2)
        {
            Dictionary<string, double> result = new Dictionary<string, double>();

            if (d1 == null || gd2 == null) { return null; }

            foreach (string s in gd2.Keys)
            {

                if (d1.ContainsKey(s) == true)
                {
                    result.Add(s, d1[s] + Convert.ToDouble(gd2[s]));
                }

            }
            return result;
        }

        public Dictionary<string, double> Rescore(Dictionary<string, double> d1, Dictionary<string, double> gd2)
        {
            Dictionary<string, double> result = new Dictionary<string, double>();

            if (d1 == null || gd2 == null) { return null; }

            foreach (string s in gd2.Keys)
            {

                if (d1.ContainsKey(s) == true)
                {
                    result.Add(s, d1[s] + gd2[s]);
                }

            }
            return result;
        }

        public Dictionary<string, List<double>> GraphScoreCombiner(List<string> docId, List<double> distance)
        {
            if (docId == null || distance == null || docId.Count != distance.Count) { return null; }

            Dictionary<string, List<double>> result = new Dictionary<string, List<double>>();
            List<double> existing;

            for (int i = 0; i < docId.Count; i++)
            {
                if (!result.ContainsKey(docId[i]))
                {
                    existing = new List<double>();
                    existing.Add(distance[i]);
                    result[docId[i]] = existing;
                }
                // At this point we know that "existing" refers to the relevant list in the 
                // dictionary, one way or another.
                existing = result[docId[i]];
                existing.Add(distance[i]);
            }

            return result;
        }

        public Dictionary<string, double> GraphScoreCalculator(Dictionary<string, List<double>> distance)
        {
            if (distance == null) { return null; }

            Dictionary<string, double> result = new Dictionary<string, double>();
            double score = 0;

            foreach (string s in distance.Keys)
            {
                score = 0;
                foreach (double d in distance[s])
                {
                    score = score + (1 / d);
                }
                result.Add(s, score);
            }

            return result;
        }

    }
}
