﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Neo4j1
{
    public class User
    {
        public string Name { get; set; }
        public string Partnercode { get; set; }
        //public List<string> recent_tran { get; set; }
        //public string user_name { get; set; }
    }

}
