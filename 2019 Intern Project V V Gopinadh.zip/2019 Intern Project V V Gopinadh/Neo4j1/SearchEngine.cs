﻿using Elasticsearch.Net;
using Nest;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Text;

namespace Neo4j1
{
    public class SearchEngine
    {
        public ElasticClient client { get; set; }
        public JArray source { get; set; }

        public SearchEngine(string uri, string defaultIndex = null)
        {
            this.source = new JArray();
            this.InitializeEngine(uri, defaultIndex);
        }

        public void InitializeEngine(string uri, string defaultIndex = null)
        {
            ConnectionSettings settings;

            if (defaultIndex != null)
            {
                settings = new ConnectionSettings(new Uri(uri)).DefaultIndex(defaultIndex).DisableDirectStreaming();
            }
            else
            {
                settings = new ConnectionSettings(new Uri(uri));
            }

            this.client = new ElasticClient(settings);
        }

        public void Search(string index, string[] field, string value)
        {
            JArray results;
            JObject json_result;
            StringResponse searchResponse;
            int size;

            this.source.Clear();

            searchResponse = client.LowLevel.Search<StringResponse>(index, PostData.Serializable(new
            {
                query = new
                {
                    multi_match = new
                    {
                        fields = field,
                        query = value
                    }
                }
            }));

            json_result = JObject.Parse(searchResponse.Body);

            //nothing found in search
            if (json_result == null || json_result["hits"]["total"]["value"].Equals("0"))
            {
                return;
            }
            results = JArray.FromObject(json_result["hits"]["hits"]);
            size = results.Count;

            for (int i = 0; i < size; i++)
            {
                this.source.Add(results[i]);
            }

            return;
        }

        public List<T> ExtractResults<T>()
        {
            if (this.source.Count == 0)
            {
                return null;
            }
            //this.source.Clear();
            List<T> resultList = new List<T>();
            int size = this.source.Count;
            for (int i = 0; i < size; i++)
            {
                resultList.Add(this.source[i]["_source"].ToObject<T>());
                //Console.WriteLine(this.source[i].ToObject<T>());
            }
            return resultList;
        }

        public List<T> ExtractSubResult<T>(string property)
        {
            if (this.source.Count == 0)
            {
                return null;
            }
            List<T> subResult = new List<T>();
            int size = this.source.Count;
            for (int i = 0; i < size; i++)
            {

                foreach (JObject j in this.source[i]["_source"][property])
                {
                    subResult.Add(j.ToObject<T>());
                }
            }
            return subResult;
        }

        public List<T> ExtractProperty<T>(string property)
        {
            if (this.source.Count == 0)
            {
                return null;
            }
            List<T> subResult = new List<T>();
            int size = this.source.Count;
            for (int i = 0; i < size; i++)
            {
                subResult.Add(this.source[i]["_source"][property].ToObject<T>());
            }
            return subResult;
        }

        public Dictionary<T1, T2> ExtractProperties<T1, T2>(string property1, string property2, bool exter)
        {
            if (this.source.Count == 0)
            {
                return null;
            }

            if (exter == false)
            {
                Dictionary<T1, T2> prop = new Dictionary<T1, T2>();
                int size = this.source.Count;
                for (int i = 0; i < size; i++)
                {
                    prop.Add(this.source[i]["_source"][property1].ToObject<T1>(), this.source[i][property2].ToObject<T2>());
                }
                return prop;
            }

            else
            {
                Dictionary<T1, T2> prop = new Dictionary<T1, T2>();
                int size = this.source.Count;
                for (int i = 0; i < size; i++)
                {
                    prop.Add(this.source[i]["_source"][property1].ToObject<T1>(), this.source[i]["_source"][property2].ToObject<T2>());
                }
                return prop;
            }

        }
    }
}
